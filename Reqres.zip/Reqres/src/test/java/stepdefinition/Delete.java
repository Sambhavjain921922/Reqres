package stepdefinition;
import org.testng.Assert;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class Delete {
	private Response response;
{
}
	@When("Get call to url {string}")
	public void Get_call_to_url(String url) {
		RequestSpecification requestSpecification = RestAssured.given();
		response = requestSpecification.when().delete(url);
		System.out.println(response.getBody().asPrettyString());
}
	
	@Then("Response is statuscode {string}")
		public void Response_is_statuscode(String statuscode)
		{
			int actualResponseCode = response.then().extract().statusCode();
			Assert.assertEquals(statuscode,actualResponseCode+"");
		}
 }