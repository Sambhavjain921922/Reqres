package stepdefinition;
import org.testng.Assert;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Patch {
	private Response response;
{
}

	@When("Enter a url of regres {string} and data as name {string} and job {string}")
	public void enter_a_url_of_regres_and_data_as_name_and_job(String url, String name, String job){
		RequestSpecification httpreq = RestAssured.given().header("Content-Type","application/json");
		String body = "{\"name\":\""+name+"\", "
				+ "\"job\":\""+job+"\"}";
		response = httpreq.body(body).when().patch(url).then().extract().response();
		System.out.println(response.getBody().asPrettyString());
	}
	
	@Then("Response of the statuscode {string}")
	public void response_of_the_statuscode(String statuscode) {
		int actualResponseCode = response.then().extract().statusCode();
		Assert.assertEquals(statuscode,actualResponseCode+"");
		}
}