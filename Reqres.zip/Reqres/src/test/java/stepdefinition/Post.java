package stepdefinition;
import org.testng.Assert;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Post {
	private Response response;
{
}

	@When("Enter a url {string} and name {string} and job {string}")
	public void enter_a_url_and_name_and_job(String url, String name, String job){
		RequestSpecification httpreq = RestAssured.given().header("Content-Type","application/json");
		String body = "{\"name\":\""+name+"\", "
				+ "\"job\":\""+job+"\"}";
		response = httpreq.body(body).when().post(url).then().extract().response();
		System.out.println(response.getBody().asPrettyString());
	}
	

	@Then("Response is the {string}")
	public void response_is_the(String statuscode) {
		int actualResponseCode = response.then().extract().statusCode();
		Assert.assertEquals(statuscode,actualResponseCode+"");
	}
	
	@When("Enter a url {string} and data username as {string} and password as {string}")
	public void enter_a_url_and_data_and_data_username_as_and_password_as(String url, String email, String password){
		RequestSpecification httpreq = RestAssured.given().header("Content-Type","application/json");
		String body = "{\"email\":\""+email+"\", "
				+ "\"password\":\""+password+"\"}";
		response = httpreq.body(body).when().post(url).then().extract().response();
		System.out.println(response.getBody().asPrettyString());
	}
	
	@When("Enter a url {string} and data username as {string}")
	public void enter_a_url_and_data_and_data_username_as(String url, String email){
		RequestSpecification httpreq = RestAssured.given().header("Content-Type","application/json");
		String body = "{\"email\":\""+email+"\", ";
		response = httpreq.body(body).when().post(url).then().extract().response();
		System.out.println(response.getBody().asPrettyString());
	}
}